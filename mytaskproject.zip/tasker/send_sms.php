<?php
require 'vendor/autoload.php'; // Include Twilio PHP SDK

use Twilio\Rest\Client;

// Twilio credentials
$accountSid = 'ACd67d822e943e30825600617cd1e7c698';  // Replace with your Twilio Account SID
$authToken = '9f5977097da1e006b2b8803352d984eb';    // Replace with your Twilio Auth Token
$twilioPhoneNumber = '14342523416'; // Replace with your Twilio phone number

// Read the incoming data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
    exit;
}

// Extract details
$name = $data['name'];
$mobile = $data['mobile'];
$roomType = $data['roomType'];
$checkin = $data['checkin'];
$checkout = $data['checkout'];

// Construct the SMS message
$messageBody = "Thank you for booking with LS Home Stay, $name. Room Details: $roomType. Check-in: $checkin, Check-out: $checkout.";

try {
    // Initialize Twilio client
    $client = new Client($accountSid, $authToken);

    // Send the SMS
    $message = $client->messages->create(
        $mobile, // Destination phone number
        [
            'from' => $twilioPhoneNumber, // Twilio phone number
            'body' => $messageBody
        ]
    );

    // Respond with success
    echo json_encode(['success' => true, 'messageSid' => $message->sid]);
} catch (Exception $e) {
    // Respond with error
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>

