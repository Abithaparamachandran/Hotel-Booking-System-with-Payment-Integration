<?php

$access_token = 'EABZBGTyorwRkBOZBVJhSZBx0ZBX2iSh00G6FeXxf0yW74Aq1YkejluZCoZBEItC0nHRhFt7lWMI5B2jWQnQPhBMvr2t6y0nVaz0yzecZAOZBzLmLe1xXg7YNgdTW6ApkFxzIY6jtLqGa66W1GEKnl4aDHfAg9Ai0DpG24myiKev2evW2E730kDewyu2I91fpmZArxB2thAEZA5hudtl2OA03l6bBNul70ZD';
$phone_number_id = '528145707044622'; 
$recipient_phone_number = '+918072777283'; 
$message = 'Hello, this is a test message!';


$api_url = "https://graph.facebook.com/v15.0/$phone_number_id/messages";


$data = [
	    "messaging_product" => "whatsapp",
	        "to" => $recipient_phone_number,
		    "type" => "text", 
		        "text" => [
				        "body" => $message  
					    ]
				    ];


$headers = [
	    "Authorization: Bearer $access_token",  
	        "Content-Type: application/json"        
	];

$ch = curl_init($api_url);


curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_POST, true);            
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); 

$response = curl_exec($ch);


curl_close($ch);


echo $response;
?>
